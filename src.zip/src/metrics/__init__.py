# from .map import MAPMetric
from metrics.old_metric_collection import MetricCollection
