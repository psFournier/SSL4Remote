#!/bin/bash

qsub -v PARAMS=" " ~/SemiSupervised/SSL4Remote/src/scripts/vre/pbs_train.sh
